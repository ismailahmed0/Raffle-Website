def bob():
    return "My name Is Still John Elder"